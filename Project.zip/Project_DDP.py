import os
from tkinter import *
import ttkbootstrap as tb

class SystemControl:
    def __init__(self, master):
        self.master = master
        master.title("System Control")

        self.label = Label(master, text="Pilih aksi yang ingin dilakukan:", padx=20 , font=("ink free",30))
        self.label.pack(pady=20)

        self.shutdown_button = Button(master, text="Shutdown",font=("timesnewroman",20, "bold"), width=20, command=self.shutdown)
        self.shutdown_button.pack(pady=20)

        self.restart_button = Button(master, text="Restart", font=("timesnewroman",20, "bold"), width=20 , command=self.restart)
        self.restart_button.pack(pady=20)

        self.logout_button = Button(master, text="Logout", font=("timesnewroman",20, "bold"), width=20 , command=self.logout)
        self.logout_button.pack(pady=20) 

    def shutdown(self):
        os.system("shutdown /s /t 1")

    def restart(self):
        os.system("shutdown /r /t 1")

    def logout(self):
        os.system("shutdown -l")

root = tb.Window(themename="superhero")
my_gui = SystemControl(root)
root.mainloop()
